import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _056721b8 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _68f9c14e = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _b5cdd7a2 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _c768d622 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _7e67199d = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _f9d44f88 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))
const _1d04d532 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _056721b8,
    children: [{
      path: "/",
      component: _68f9c14e,
      name: "home"
    }, {
      path: "/login",
      component: _b5cdd7a2,
      name: "login"
    }, {
      path: "/register",
      component: _b5cdd7a2,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _c768d622,
      name: "profile"
    }, {
      path: "/settings",
      component: _7e67199d,
      name: "settings"
    }, {
      path: "/article/:slug",
      component: _f9d44f88,
      name: "article"
    }, {
      path: "/create",
      component: _1d04d532,
      name: "create"
    }, {
      path: "/editor",
      component: _1d04d532,
      name: "edit"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
